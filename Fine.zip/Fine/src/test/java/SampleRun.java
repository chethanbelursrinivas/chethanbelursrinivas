

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import junit.framework.Assert;


public class SampleRun {
	DriverManager driverManager;
	WebDriver driver;
	LoginPageClass loginPage;
	@BeforeClass
	public void setup(){
		driverManager=DriverMangerFactory.getDriverManager(DriverType.CHROME);	
		driver=driverManager.getWebDriver();
		driver.get("https://Google.com");
	}
	
	@Test
	public void googleValidation() throws InterruptedException{
		loginPage = new LoginPageClass(driver);
		loginPage.clickSerachFeild();
		loginPage.enterText();
		loginPage.serachtheKey();
		boolean result = loginPage.validateLink();
		Assert.assertFalse(result);
	}
	
	@AfterClass
	public void closeBrower()
	{
		driver.quit();
	}
}