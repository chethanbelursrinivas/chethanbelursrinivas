import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPageClass {
	
	WebDriver driver;
	public LoginPageClass(WebDriver driver){
		this.driver = driver;
	}

	private By googleSerachFeild = By.xpath("//div//input[contains(@title,'Search')]");
	private By googleSerachButton = By.xpath("(//div//input[contains(@value,'Google Search')])[1]");
	private By link = By.xpath("//div//link[contains(@href,'https://www.selenium.dev')]");
	
	
	public void clickSerachFeild(){
		driver.findElement(googleSerachFeild).click();
		
	}
	
	public void enterText(){
		driver.findElement(googleSerachFeild).sendKeys("Selenium");
	}
	public void serachtheKey(){
		driver.findElement(googleSerachButton).click();
	}
	
	public boolean validateLink(){
		return driver.findElement(link).isDisplayed();
	}
	
}
